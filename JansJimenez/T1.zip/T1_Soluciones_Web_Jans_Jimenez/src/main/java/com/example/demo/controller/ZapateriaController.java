package com.example.demo.controller;

import com.example.demo.model.Zapateria;
import com.example.demo.service.ZapateriaService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/zapateria") // Endpoint para pruebas en Postman [cite: 25, 67, 87]
public class ZapateriaController {

    private final ZapateriaService service;

    public ZapateriaController(ZapateriaService service) {
        this.service = service;
    }

    @GetMapping
    public List<Zapateria> obtenerTodas() {
        return service.listar();
    }

    @PostMapping
    public Zapateria registrar(@Valid @RequestBody Zapateria zapateria) {
        return service.guardar(zapateria);
    }
}
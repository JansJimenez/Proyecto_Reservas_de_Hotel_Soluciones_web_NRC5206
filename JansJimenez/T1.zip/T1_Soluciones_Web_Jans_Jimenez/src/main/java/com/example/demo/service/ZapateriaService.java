package com.example.demo.service;

import com.example.demo.model.Zapateria;
import com.example.demo.repository.ZapateriaRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ZapateriaService {
    // Inyección de dependencias por constructor [cite: 18, 19, 85]
    private final ZapateriaRepository repository;

    public ZapateriaService(ZapateriaRepository repository) {
        this.repository = repository;
    }

    public List<Zapateria> listar() {
        return repository.findAll();
    }

    public Zapateria guardar(Zapateria zapateria) {
        return repository.save(zapateria);
    }
}